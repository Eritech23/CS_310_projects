package pa0;
// Import packages as needed

// LineUsageData.java: Handle one line's data, using a Map
public class LineUsage {
	// Variables here

	// Constructor
	public LineUsage() {
	}

	// add one sighting of a user on this line
	public void addObservation(String username) {
	}

	// find the user with the most sightings on this line
	public Usage findMaxUsage() {
	}
}
