package pa0;
// One user's record on one line: how many times
// this user has been seen on this line
public class Usage {
	// Put variables here.

	public Usage(String x, int count) {
	}

	public void setCount(int x) {
	}

	public String getUser() {
	}

	public int getCount() {
	}
}
