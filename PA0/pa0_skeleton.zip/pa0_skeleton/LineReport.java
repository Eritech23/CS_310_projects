package pa0;
// Import here as needed

public class LineReport {
	// Variables here

	// Constructor
	public LineReport() {}

	// read input data, put facts into lines array
	void loadData(String fname) {}

	// given loaded lines array, generate report on lines
	void generateReport() {}

	public static void main(String[] args) {}
}
